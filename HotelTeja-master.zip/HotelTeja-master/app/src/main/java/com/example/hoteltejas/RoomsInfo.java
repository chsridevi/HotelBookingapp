package com.example.hoteltejas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RoomsInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rooms_info);
    }
}
